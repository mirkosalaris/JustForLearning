import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Set; 
import java.util.HashSet; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class stringy_shapes extends PApplet {




// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.


/******************* DESCRIPTION *******************
  * This program lets you draw stringy (and blinky) shapes.
  * Three buttons: new shape, reset, red/blue.
  * What is a shape? A set of point. There will be a line between each pair of points.
  * Pressing new shape generates, unsurprisingly, a new shape.
  * Reset button, guess it, just resets the whole board.
  * Red/blue button, here you need a bit of imagination, change color of the shapes, between red and blue.
  */

protected final int RED = color(240, 15, 15);
protected final int BLUE = color(15, 15, 240);

protected int lineColor;
private Set<Shape> shapeSet = new HashSet<Shape>();
private Shape currentShape;

private ControllerPanel panel = new ControllerPanel();

public void setup() {
  reset(); // initialize
  
  panel.add(new Button(2, 2, 90, 18, "new shape", new NewShapeCallback()));
  panel.add(new Button(100, 2, 90, 18, "reset", new ResetCallback()));
  panel.add(new Button(200, 2, 90, 18, "red/blue", new ColorCallback()));
  
  textAlign(CENTER, TOP);
  textSize(14);
  background(255);
  
  
  // limit the number of frames per second
  frameRate(30);
} 

public void draw() {
  background(255);
  
  panel.draw(); // draw the controllers
  
  for (Shape s: shapeSet) {
    s.draw(lineColor);
  }
}

/**
 * reset and initialize
 */
public void reset() {
  shapeSet = new HashSet<Shape>();
  currentShape = new Shape();
  shapeSet.add(currentShape);
  lineColor = RED;
}

public void mouseClicked() {
  // send to panel the click
  boolean handled = panel.click();
  
  // if not already handled
  if (!handled && currentShape != null) {
    // save the point into current shape
    currentShape.addPoint(new Point(mouseX, mouseY));
  }
}
// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Button extends Controller {
  private int x, y, width, height;
  private String label;
  private Callback callback;
  
  Button(int x, int y, int width, int height, String label, Callback cbk) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.label = label;
    this.callback = cbk;
  }

  public boolean click() {
    boolean handled = false;
    if (this.mouseOn()) {
      callback.call(); 
      handled = true;
    }
    return handled;
  }
  
  public void draw() {
    stroke(50, 50, 50);
    if (this.mouseOn()) {
      fill(240);
    } else {
      fill(210);
    }
    rect(x, y, width, height);
    
    fill(20, 20, 20);
    text(label, x, y, width, height);
  }
  
  /**
   * returns true if the mouse is inside the button region
   */
  public boolean mouseOn() {
      return (x <= mouseX) && (mouseX <= x + width)
             && (y <= mouseY) && (mouseY <= y + height);  
  }
}
// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

interface Callback {
 public void call(); 
}

class ResetCallback implements Callback {
  public void call() {
      reset();
  }
}

class NewShapeCallback implements Callback {
  public void call() {
    currentShape = new Shape();
    shapeSet.add(currentShape);
   }
}

class ColorCallback implements Callback {
  public void call() {
    if (lineColor == RED)
      lineColor = BLUE;
    else
      lineColor = RED;
  }
}
// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

abstract class Controller {
  // activate the action associated with the click
  // returns true if the click has been handled, false otherwise
  public abstract boolean click();
  
  // draw the controller
  public abstract void draw();
}
// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

class ControllerPanel {
  Set<Controller> controllers = new HashSet<Controller>();
  
  public void draw() {
    for (Controller c: controllers) {
      c.draw();
    }
  }
  
  public boolean click() {
    boolean handled = false;
    
    // "try" to click on each controller. If some click applies, return true
    for (Controller c: controllers) {
      if (c.click() == true)
        handled = true;
    }
    
    return handled;
  }
  
  // add a new controller to the panel
  public void add(Controller c) {
    controllers.add(c);
  }
}
// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Point {
    private int x, y;
    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public boolean equals(Point p1, Point p2) {
       return (p1.x == p2.x && p1.y == p2.y); 
    }
}
// Stringy Shapes - Copyright (C) 2018 - Mirko Salaris
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

class Shape {
  Set<Point> pointSet = new HashSet<Point>();
  public void addPoint(Point p) {
   pointSet.add(p);
  }
  
  public void draw(int lineColor) {
    stroke(lineColor);
    strokeWeight(1);
    for (Point p1: pointSet) {
    
      for(Point p2: pointSet) {
        if (!p2.equals(p1) && random(1) < 0.7f) { // random -> blink effect
          line(p1.x, p1.y, p2.x, p2.y);
        }
      }
    
    }
  }
  
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "stringy_shapes" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
